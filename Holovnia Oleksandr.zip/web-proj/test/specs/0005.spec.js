describe('Saving the card after logout', () => {
  before(async () => {
    // Step 1: Open the page and login
    await browser.url('https://www.saucedemo.com/');
    const usernameField = await $('#user-name');
    const passwordField = await $('#password');
    const loginButton = await $('#login-button');
    
    // Log in with valid credentials
    await usernameField.setValue('standard_user');
    await passwordField.setValue('secret_sauce');
    await loginButton.click();
  });

  it('should save the cart after logout and login again', async () => {
    // Step 1: Click on the "Add to cart" button near any product
    const addToCartButton = await $('.inventory_item:nth-child(1) .btn_inventory'); // Example for the first product
    await addToCartButton.click();

    // Step 2: Click on the "Burger" button to open the menu
    const burgerButton = await $('#react-burger-menu-btn');
    await burgerButton.click();

    // Wait for the menu to be displayed
    const menu = await $('nav.bm-item-list');
    await menu.waitForDisplayed();

    // Step 3: Click on the "Logout" button
    const logoutButton = await $('#logout_sidebar_link');
    await logoutButton.click();

    // Step 4: Verify user is redirected to the login page
    const usernameField = await $('#user-name');
    const passwordField = await $('#password');
    expect(await usernameField.getValue()).toBe('');
    expect(await passwordField.getValue()).toBe('');
    expect(await usernameField.isDisplayed()).toBe(true);
    expect(await passwordField.isDisplayed()).toBe(true);

    // Step 5: Login again with the same valid credentials
    await usernameField.setValue('standard_user');
    await passwordField.setValue('secret_sauce');
    const loginButtonAgain = await $('#login-button');
    await loginButtonAgain.click();

    // Step 6: Verify user is redirected to the inventory page
    const inventoryTitle = await $('.inventory_list');
    await inventoryTitle.waitForDisplayed();

    // Step 7: Click on the "Cart" button to go to the cart page
    const cartButton = await $('.shopping_cart_link');
    await cartButton.click();

    // Step 8: Verify the cart page displays the same product added earlier
    const cartItems = await $$('div.cart_item');
    expect(cartItems.length).toBe(1);  // Expected result: 1 item in the cart
  });
});
