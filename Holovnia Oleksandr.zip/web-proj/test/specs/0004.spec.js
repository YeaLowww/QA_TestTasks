describe('Logout Test', () => {
  before(async () => {
    // Step 1: Open the page and login
    await browser.url('https://www.saucedemo.com/');
    const usernameField = await $('#user-name');
    const passwordField = await $('#password');
    const loginButton = await $('#login-button');
    
    // Log in with valid credentials
    await usernameField.setValue('standard_user');
    await passwordField.setValue('secret_sauce');
    await loginButton.click();
  });

  it('should logout successfully', async () => {
    // Step 1: Click on the "Burger" button to open the menu
    const burgerButton = await $('#react-burger-menu-btn');
    await burgerButton.click();

    // Wait for the menu to be displayed
    const menu = await $('nav.bm-item-list');
    await menu.waitForDisplayed();

    // Check that 4 items are displayed
    const menuItems = await $$('nav.bm-item-list > a');
    expect(menuItems.length).toBe(4);  // Expected result: 4 items

    // Step 2: Click on the "Logout" button
    const logoutButton = await $('#logout_sidebar_link');
    await logoutButton.click();

    // Step 3: Verify that the user is redirected to the login page
    const usernameField = await $('#user-name');
    const passwordField = await $('#password');
    
    // Check that the fields are empty, meaning the user is logged out
    expect(await usernameField.getValue()).toBe('');  // Username field should be empty
    expect(await passwordField.getValue()).toBe('');  // Password field should be empty

    // Ensure that the fields are displayed (login page is shown)
    expect(await usernameField.isDisplayed()).toBe(true);
    expect(await passwordField.isDisplayed()).toBe(true);
  });
});
