describe('Login with invalid login', () => {
    it('should display an error message when the login is incorrect', () => {
        // Step 1: Open the login page
        browser.url('https://www.example.com/login');

        // Step 2: Enter an invalid username into the "Login" field
        const loginField = $('#login');
        loginField.setValue('standarD_user'); // You can replace this with any random value

        // Step 3: Enter a valid password into the "Password" field
        const passwordField = $('#password');
        passwordField.setValue('secret_sauce');

        // Step 4: Click the "Login" button
        const loginButton = $('#loginButton');
        loginButton.click();

        // Step 5: Validate that "X" icons are displayed and the fields are highlighted with red
        const loginFieldErrorIcon = $('#login + .error-icon');
        const passwordFieldErrorIcon = $('#password + .error-icon');
        const loginFieldBorder = $('#login');
        const passwordFieldBorder = $('#password');

        expect(loginFieldErrorIcon).toBeDisplayed();
        expect(passwordFieldErrorIcon).toBeDisplayed();
        expect(loginFieldBorder).toHaveStyle({ borderColor: 'red' });
        expect(passwordFieldBorder).toHaveStyle({ borderColor: 'red' });

        // Step 6: Validate that the error message is displayed
        const errorMessage = $('.error-message');

        // Use toHaveText instead of toHaveTextContaining
        expect(errorMessage).toHaveText('Epic sadface: Username and password do not match any user in this service');
    });
});
