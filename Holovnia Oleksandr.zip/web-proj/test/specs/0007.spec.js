describe('Footer Links on Inventory Page', () => {
    before(async () => {
        // Вхід в систему
        await browser.url('https://www.saucedemo.com/');
        await $('#user-name').setValue('standard_user');
        await $('#password').setValue('secret_sauce');
        await $('#login-button').click();

        // Перевірка, що сторінка інвентаря завантажена
        const inventoryList = await $('.inventory_list');
        await inventoryList.waitForDisplayed();
    });

    it('should open Twitter link in a new tab', async () => {
        // Очікування перед кліком
        const twitterIcon = await $('.social_twitter a');
        await twitterIcon.waitForDisplayed();
        await twitterIcon.click();

        // Переключення на нову вкладку
        const handles = await browser.getWindowHandles();
        await browser.switchToWindow(handles[1]);

        // Перевірка, що відкрито сторінку Twitter (X.com)
        const currentUrl = await browser.getUrl();
        expect(currentUrl).toContain('x.com'); // Або 'twitter.com', залежно від поточного URL

        // Закриття нової вкладки
        await browser.closeWindow();

        // Повернення на головну вкладку
        await browser.switchToWindow(handles[0]);

        // Перевірка, що ми повернулися на головну сторінку
        const mainUrl = await browser.getUrl();
        expect(mainUrl).toContain('inventory.html');
    });

    it('should open Facebook link in a new tab', async () => {
        // Очікування перед кліком
        const facebookIcon = await $('.social_facebook a');
        await facebookIcon.waitForDisplayed({ timeout: 15000 }); // Збільште таймаут, якщо потрібно
        await facebookIcon.click();

        // Переключення на нову вкладку
        const handles = await browser.getWindowHandles();
        await browser.switchToWindow(handles[1]);

        // Перевірка, що відкрито сторінку Facebook
        const currentUrl = await browser.getUrl();
        expect(currentUrl).toContain('facebook.com');

        // Закриття нової вкладки
        await browser.closeWindow();

        // Повернення на головну вкладку
        await browser.switchToWindow(handles[0]);

        // Перевірка, що ми повернулися на головну сторінку
        const mainUrl = await browser.getUrl();
        expect(mainUrl).toContain('inventory.html');
    });

    it('should open LinkedIn link in a new tab', async () => {
        // Очікування перед кліком
        const linkedinIcon = await $('.social_linkedin a');
        await linkedinIcon.waitForDisplayed({ timeout: 15000 }); // Збільште таймаут, якщо потрібно
        await linkedinIcon.click();

        // Переключення на нову вкладку
        const handles = await browser.getWindowHandles();
        await browser.switchToWindow(handles[1]);

        // Перевірка, що відкрито сторінку LinkedIn
        const currentUrl = await browser.getUrl();
        expect(currentUrl).toContain('linkedin.com');

        // Закриття нової вкладки
        await browser.closeWindow();

        // Повернення на головну вкладку
        await browser.switchToWindow(handles[0]);

        // Перевірка, що ми повернулися на головну сторінку
        const mainUrl = await browser.getUrl();
        expect(mainUrl).toContain('inventory.html');
    });
});