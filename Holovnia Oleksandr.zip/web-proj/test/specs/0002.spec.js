describe('Login with invalid password', () => {
    it('should display an error message when the password is incorrect', () => {
        // Step 1: Open the login page
        browser.url('https://www.example.com/login');

        // Step 2: Enter a valid username into the "Login" field
        const loginField = $('#login');
        loginField.setValue('standard_user');

        // Step 3: Enter an invalid password into the "Password" field
        const passwordField = $('#password');
        passwordField.setValue('anyRandomValue');

        // Step 4: Click the "Login" button
        const loginButton = $('#loginButton');
        loginButton.click();

        // Step 5: Validate that "X" icons are displayed and the fields are highlighted with red
        const loginFieldErrorIcon = $('#login + .error-icon');
        const passwordFieldErrorIcon = $('#password + .error-icon');
        const loginFieldBorder = $('#login');
        const passwordFieldBorder = $('#password');

        expect(loginFieldErrorIcon).toBeDisplayed();
        expect(passwordFieldErrorIcon).toBeDisplayed();
        expect(loginFieldBorder).toHaveStyle({ borderColor: 'red' });
        expect(passwordFieldBorder).toHaveStyle({ borderColor: 'red' });

        // Step 6: Validate that the error message is displayed
        const errorMessage = $('.error-message');
        
        // Use toHaveText instead of toHaveTextContaining
        expect(errorMessage).toHaveText('Epic sadface: Username and password do not match any user in this service');
    });
});
