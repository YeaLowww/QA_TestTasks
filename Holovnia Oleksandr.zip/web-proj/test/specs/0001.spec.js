describe('Valid Login Test', () => {
    it('should log in with valid credentials', async () => {
        // Перехід на сторінку логіну
        await browser.url('https://www.saucedemo.com/');

        // Введення логіну
        const loginField = await $('#user-name');
        await loginField.setValue('standard_user');

        // Введення паролю
        const passwordField = await $('#password');
        await passwordField.setValue('secret_sauce');

        // Натискання кнопки "Login"
        const loginButton = await $('#login-button');
        await loginButton.click();

        // Перевірка, чи користувач був перенаправлений на сторінку інвентарю
        const inventoryPage = await $('#inventory_container');
        await inventoryPage.waitForDisplayed();

        // Перевірка, чи відображаються продукти та кошик
        const products = await $$('.inventory_item');
        expect(products.length).toBeGreaterThan(0); // Перевірка на наявність продуктів

        const cartIcon = await $('.shopping_cart_link');
        expect(await cartIcon.isDisplayed()).toBe(true); // Перевірка наявності кошика
    });
});
