describe('Sorting products on inventory page', () => {
    before(async () => {
        await browser.url('https://www.saucedemo.com/');
        await $('#user-name').setValue('standard_user');
        await $('#password').setValue('secret_sauce');
        await $('#login-button').click();

        // Проверяем, что страница инвентаря загружена
        const inventoryList = await $('.inventory_list');
        await inventoryList.waitForDisplayed();
    });

    const sortingOptions = [
        { value: 'lohi', type: 'Price (low to high)', comparator: (a, b) => a - b },
        { value: 'hilo', type: 'Price (high to low)', comparator: (a, b) => b - a },
        { value: 'az', type: 'Name (A to Z)', comparator: (a, b) => a.localeCompare(b) },
        { value: 'za', type: 'Name (Z to A)', comparator: (a, b) => b.localeCompare(a) }
    ];

    sortingOptions.forEach(({ value, type, comparator }) => {
        it(`should sort products correctly by ${type}`, async () => {
            // Выбираем сортировку
            const sortDropdown = await $('.product_sort_container');
            await sortDropdown.waitForDisplayed();
            await sortDropdown.selectByAttribute('value', value);

            // Дожидаемся обновления списка товаров
            await browser.pause(2000);
            const productElements = await $$('.inventory_item');

            // Проверяем, что товары загружены
            expect(productElements.length).toBeGreaterThan(0);

            // Извлекаем названия товаров
            const names = [];
            for (const el of productElements) {
                const nameElement = await el.$('.inventory_item_name');
                if (await nameElement.isExisting()) {
                    names.push(await nameElement.getText());
                }
            }

            // Извлекаем цены товаров
            const prices = [];
            for (const el of productElements) {
                const priceElement = await el.$('.inventory_item_price');
                if (await priceElement.isExisting()) {
                    const priceText = await priceElement.getText();
                    prices.push(parseFloat(priceText.replace('$', '')));
                }
            }

            // Выбираем, что сортировать
            const currentOrder = value.includes('price') ? prices : names;
            const expectedOrder = [...currentOrder].sort(comparator);

            // Проверяем, что список отсортирован правильно
            expect(currentOrder).toEqual(expectedOrder);
        });
    });
});
