describe('Checkout without Products', () => {
    before(async () => {
        // Вхід в систему
        await browser.url('https://www.saucedemo.com/');
        await $('#user-name').setValue('standard_user');
        await $('#password').setValue('secret_sauce');
        await $('#login-button').click();

        // Перевірка, що сторінка інвентаря завантажена
        const inventoryList = await $('.inventory_list');
        await inventoryList.waitForDisplayed();
    });

    it('should open the cart and verify it is empty', async () => {
        // Клік на іконку кошика
        const cartIcon = await $('.shopping_cart_link');
        await cartIcon.click();

        // Перевірка, що сторінка кошика відображається
        const cartPageTitle = await $('.title');
        await cartPageTitle.waitForDisplayed();
        expect(await cartPageTitle.getText()).toEqual('Your Cart');

        // Перевірка, що кошик порожній
        const cartItems = await $$('.cart_item');
        expect(cartItems.length).toBe(0); // Немає товарів у кошику
    });

    it('should display an error message when trying to checkout with an empty cart', async () => {
        // Клік на кнопку "Checkout"
        const checkoutButton = await $('#checkout');
        await checkoutButton.click();

        // Перевірка, що користувач залишається на сторінці кошика
        const cartPageTitle = await $('.title');
        await cartPageTitle.waitForDisplayed();
        expect(await cartPageTitle.getText()).toEqual('Your Cart');

        // Перевірка, що відображається повідомлення про помилку
        const errorMessage = await $('.error-message-container'); // Селектор для повідомлення про помилку
        await errorMessage.waitForDisplayed();
        expect(await errorMessage.getText()).toContain('Cart is empty');
    });
});