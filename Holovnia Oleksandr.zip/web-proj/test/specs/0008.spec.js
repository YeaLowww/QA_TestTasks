describe('Valid Checkout Process', () => {
    before(async () => {
        // Вхід в систему
        await browser.url('https://www.saucedemo.com/');
        await $('#user-name').setValue('standard_user');
        await $('#password').setValue('secret_sauce');
        await $('#login-button').click();

        // Перевірка, що сторінка інвентаря завантажена
        const inventoryList = await $('.inventory_list');
        await inventoryList.waitForDisplayed();
    });

    it('should add a product to the cart and verify the cart count', async () => {
        // Клік на кнопку "Add to cart" для першого продукту
        const addToCartButton = await $('.btn_inventory');
        await addToCartButton.click();

        // Перевірка, що кількість товарів у кошику збільшилася на 1
        const cartBadge = await $('.shopping_cart_badge');
        await cartBadge.waitForDisplayed();
        expect(await cartBadge.getText()).toEqual('1');
    });

    it('should open the cart and verify the product', async () => {
        // Клік на іконку кошика
        const cartIcon = await $('.shopping_cart_link');
        await cartIcon.click();

        // Перевірка, що сторінка кошика відображається
        const cartPageTitle = await $('.title');
        await cartPageTitle.waitForDisplayed();
        expect(await cartPageTitle.getText()).toEqual('Your Cart');

        // Перевірка, що продукт доданий до кошика
        const cartItem = await $('.cart_item');
        await cartItem.waitForDisplayed();
        expect(await cartItem.isDisplayed()).toBe(true);
    });

    it('should proceed to checkout and fill the form', async () => {
        // Клік на кнопку "Checkout"
        const checkoutButton = await $('#checkout');
        await checkoutButton.click();

        // Перевірка, що форма оформлення замовлення відображається
        const checkoutInfo = await $('.checkout_info');
        await checkoutInfo.waitForDisplayed();

        // Заповнення форми
        await $('#first-name').setValue('John');
        await $('#last-name').setValue('Doe');
        await $('#postal-code').setValue('12345');

        // Клік на кнопку "Continue"
        const continueButton = await $('#continue');
        await continueButton.click();
    });

    it('should verify the overview page and total price', async () => {
        // Перевірка, що сторінка "Overview" відображається
        const overviewTitle = await $('.title');
        await overviewTitle.waitForDisplayed();
        expect(await overviewTitle.getText()).toEqual('Checkout: Overview');

        // Перевірка, що продукт відображається на сторінці
        const overviewItem = await $('.cart_item');
        await overviewItem.waitForDisplayed();
        expect(await overviewItem.isDisplayed()).toBe(true);

        // Перевірка загальної ціни
        const totalPrice = await $('.summary_total_label');
        await totalPrice.waitForDisplayed();
        expect(await totalPrice.getText()).toContain('Total: $');
    });

    it('should complete the checkout and verify the confirmation page', async () => {
        // Клік на кнопку "Finish"
        const finishButton = await $('#finish');
        await finishButton.click();

        // Перевірка, що сторінка підтвердження відображається
        const completeHeader = await $('.complete-header');
        await completeHeader.waitForDisplayed();
        expect(await completeHeader.getText()).toEqual('Thank you for your order!');
    });

    it('should return to the inventory page and verify the cart is empty', async () => {
        // Клік на кнопку "Back Home"
        const backHomeButton = await $('#back-to-products');
        await backHomeButton.click();

        // Перевірка, що сторінка інвентаря відображається
        const inventoryTitle = await $('.title');
        await inventoryTitle.waitForDisplayed();
        expect(await inventoryTitle.getText()).toEqual('Products');

        // Перевірка, що кошик порожній
        const cartBadge = await $('.shopping_cart_badge');
        expect(await cartBadge.isDisplayed()).toBe(false);
    });
});